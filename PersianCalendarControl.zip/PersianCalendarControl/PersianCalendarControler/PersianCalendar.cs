﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Globalization;

namespace PersianCalendarControl
{
    public class PersianCalendar : UserControl
    {
        private System.Globalization.PersianCalendar persianCalendar = new System.Globalization.PersianCalendar();
        private DateTime currentDate = DateTime.Now;
        private DateTime selectedDate;
        private Button[,] dayButtons = new Button[6, 7];
        private Label lblMonthYear;
        private Button btnPrev, btnNext, btnToday;
        private ToolTip toolTip = new ToolTip();

        private readonly string[] DariMonthNames =
        { "حمل", "ثور", "جوزا", "سرطان", "اسد", "سنبله", "میزان", "عقرب", "قوس", "جدی", "دلو", "حوت" };

        // ========== خاصیت‌های عمومی برای دریافت تاریخ انتخاب‌شده ==========
        public DateTime SelectedDate => selectedDate;

        public string SelectedDatePersian
        {
            get
            {
                if (selectedDate == null || selectedDate == default)
                    return "";
                var pc = new System.Globalization.PersianCalendar();
                return $"{pc.GetYear(selectedDate)}/{pc.GetMonth(selectedDate):D2}/{pc.GetDayOfMonth(selectedDate):D2}";
            }
        }

        public PersianCalendar()
        {
            InitializeComponent();
            SetupUI();
            UpdateCalendar();
        }

        private void InitializeComponent()
        {
            // این متد توسط VS Designer ساخته می‌شود (می‌توانید خالی بگذارید)
        }

        private void SetupUI()
        {
            this.Size = new Size(360, 340);
            this.MinimumSize = new Size(300, 300);
            this.BackColor = Color.White;
            this.Font = new Font("Tahoma", 9.5F, FontStyle.Regular);
            this.Padding = new Padding(5);

            // ========== پنل بالایی (ناوبری) ==========
            TableLayoutPanel topPanel = new TableLayoutPanel
            {
                RowCount = 1,
                ColumnCount = 4,
                Dock = DockStyle.Top,
                Height = 40,
                BackColor = Color.FromArgb(240, 240, 240)
            };
            topPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 15F));
            topPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            topPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 15F));
            topPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));

            btnPrev = new Button
            {
                Text = "<",
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.Transparent,
                Cursor = Cursors.Hand,
                Dock = DockStyle.Fill,
                Font = new Font("Tahoma", 10F, FontStyle.Bold)
            };
            btnPrev.Click += (s, e) => ChangeMonth(-1);
            topPanel.Controls.Add(btnPrev, 0, 0);

            lblMonthYear = new Label
            {
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill,
                Cursor = Cursors.Hand,
                Font = new Font("Tahoma", 10F, FontStyle.Bold),
                ForeColor = Color.FromArgb(64, 64, 64)
            };
            lblMonthYear.Click += LblMonthYear_Click;
            toolTip.SetToolTip(lblMonthYear, "برای انتخاب سال کلیک کنید");
            topPanel.Controls.Add(lblMonthYear, 1, 0);

            btnNext = new Button
            {
                Text = ">",
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.Transparent,
                Cursor = Cursors.Hand,
                Dock = DockStyle.Fill,
                Font = new Font("Tahoma", 10F, FontStyle.Bold)
            };
            btnNext.Click += (s, e) => ChangeMonth(1);
            topPanel.Controls.Add(btnNext, 2, 0);

            btnToday = new Button
            {
                Text = "امروز",
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.LightSteelBlue,
                Cursor = Cursors.Hand,
                Dock = DockStyle.Fill,
                Font = new Font("Tahoma", 9F, FontStyle.Regular)
            };
            btnToday.Click += BtnToday_Click;
            toolTip.SetToolTip(btnToday, "برو به تاریخ امروز");
            topPanel.Controls.Add(btnToday, 3, 0);

            this.Controls.Add(topPanel);

            // ========== پنل روزهای هفته ==========
            TableLayoutPanel weekDaysPanel = new TableLayoutPanel
            {
                RowCount = 1,
                ColumnCount = 7,
                Dock = DockStyle.Top,
                Height = 30,
                BackColor = Color.FromArgb(230, 240, 250),
                Padding = new Padding(1),
                Margin = new Padding(0)
            };
            for (int i = 0; i < 7; i++)
                weekDaysPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / 7));

            string[] weekDays = { "شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه" };
            for (int col = 0; col < 7; col++)
            {
                weekDaysPanel.Controls.Add(new Label
                {
                    Text = weekDays[col],
                    TextAlign = ContentAlignment.MiddleCenter,
                    Font = new Font("Tahoma", 9F, FontStyle.Bold),
                    Dock = DockStyle.Fill,
                    ForeColor = (col == 6) ? Color.Red : Color.Black
                }, col, 0);
            }
            this.Controls.Add(weekDaysPanel);

            // ========== پنل روزهای ماه ==========
            TableLayoutPanel daysPanel = new TableLayoutPanel
            {
                RowCount = 6,
                ColumnCount = 7,
                Dock = DockStyle.Fill,
                Padding = new Padding(1),
                BackColor = Color.FromArgb(250, 250, 250)
            };
            for (int i = 0; i < 7; i++)
                daysPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F / 7));
            for (int i = 0; i < 6; i++)
                daysPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F / 6));

            for (int row = 0; row < 6; row++)
            {
                for (int col = 0; col < 7; col++)
                {
                    Button btn = new Button
                    {
                        FlatStyle = FlatStyle.Flat,
                        Dock = DockStyle.Fill,
                        BackColor = Color.White,
                        ForeColor = (col == 6) ? Color.Red : Color.Black,
                        Font = new Font("Tahoma", 9F, FontStyle.Regular),
                        Cursor = Cursors.Hand,
                        TextAlign = ContentAlignment.MiddleCenter,
                        Margin = new Padding(1)
                    };
                    btn.FlatAppearance.BorderSize = 1;
                    btn.FlatAppearance.BorderColor = Color.LightGray;
                    btn.Click += DayButton_Click;
                    dayButtons[row, col] = btn;
                    daysPanel.Controls.Add(btn, col, row);
                }
            }
            this.Controls.Add(daysPanel);
        }

        private void LblMonthYear_Click(object sender, EventArgs e)
        {
            using (Form yearForm = new Form())
            {
                yearForm.Text = "انتخاب سال";
                yearForm.Size = new Size(220, 130);
                yearForm.StartPosition = FormStartPosition.CenterParent;
                yearForm.FormBorderStyle = FormBorderStyle.FixedDialog;
                yearForm.MaximizeBox = false;
                yearForm.MinimizeBox = false;
                yearForm.BackColor = Color.White;
                yearForm.Font = this.Font;

                NumericUpDown nudYear = new NumericUpDown
                {
                    Minimum = 1300,
                    Maximum = 1500,
                    Value = persianCalendar.GetYear(currentDate),
                    Left = 20,
                    Top = 20,
                    Width = 180,
                    TextAlign = HorizontalAlignment.Center,
                    Font = this.Font
                };

                Button btnOk = new Button
                {
                    Text = "تأیید",
                    Left = 30,
                    Top = 60,
                    Width = 70,
                    DialogResult = DialogResult.OK,
                    Font = this.Font
                };
                Button btnCancel = new Button
                {
                    Text = "انصراف",
                    Left = 120,
                    Top = 60,
                    Width = 70,
                    DialogResult = DialogResult.Cancel,
                    Font = this.Font
                };

                yearForm.Controls.AddRange(new Control[] { nudYear, btnOk, btnCancel });
                yearForm.AcceptButton = btnOk;
                yearForm.CancelButton = btnCancel;

                if (yearForm.ShowDialog(this) == DialogResult.OK)
                {
                    int newYear = (int)nudYear.Value;
                    int currentMonth = persianCalendar.GetMonth(currentDate);
                    int currentDay = persianCalendar.GetDayOfMonth(currentDate);
                    try
                    {
                        currentDate = persianCalendar.ToDateTime(newYear, currentMonth, currentDay, 0, 0, 0, 0);
                    }
                    catch
                    {
                        currentDate = persianCalendar.ToDateTime(newYear, currentMonth, 1, 0, 0, 0, 0);
                    }
                    UpdateCalendar();
                }
            }
        }

        private void BtnToday_Click(object sender, EventArgs e)
        {
            currentDate = DateTime.Now;
            selectedDate = currentDate;
            UpdateCalendar();
            OnDateSelected(selectedDate);
        }

        private void ChangeMonth(int delta)
        {
            currentDate = currentDate.AddMonths(delta);
            UpdateCalendar();
        }

        private void UpdateCalendar()
        {
            int persianYear = persianCalendar.GetYear(currentDate);
            int persianMonth = persianCalendar.GetMonth(currentDate);
            int persianDay = persianCalendar.GetDayOfMonth(currentDate);

            lblMonthYear.Text = $"{DariMonthNames[persianMonth - 1]} {persianYear}";

            DateTime firstOfMonth = persianCalendar.ToDateTime(persianYear, persianMonth, 1, 0, 0, 0, 0);
            int dayOfWeek = (int)firstOfMonth.DayOfWeek; // Sunday=0, Monday=1, ..., Saturday=6
            int startColumn = (dayOfWeek == 6) ? 0 : dayOfWeek + 1; // شنبه=0, یکشنبه=1, ..., جمعه=6

            int daysInMonth = persianCalendar.GetDaysInMonth(persianYear, persianMonth);

            // پاک کردن دکمه‌ها
            for (int row = 0; row < 6; row++)
                for (int col = 0; col < 7; col++)
                {
                    dayButtons[row, col].Text = "";
                    dayButtons[row, col].BackColor = Color.White;
                    dayButtons[row, col].ForeColor = (col == 6) ? Color.Red : Color.Black;
                }

            // پر کردن روزها
            int currentRow = 0;
            int currentCol = startColumn;
            for (int day = 1; day <= daysInMonth; day++)
            {
                if (currentRow < 6 && currentCol < 7)
                {
                    dayButtons[currentRow, currentCol].Text = day.ToString();

                    DateTime thisDate = persianCalendar.ToDateTime(persianYear, persianMonth, day, 0, 0, 0, 0);
                    if (thisDate.Date == selectedDate.Date)
                    {
                        dayButtons[currentRow, currentCol].BackColor = Color.LightBlue;
                        dayButtons[currentRow, currentCol].ForeColor = Color.Black;
                    }
                    else if (thisDate.Date == DateTime.Now.Date)
                    {
                        dayButtons[currentRow, currentCol].BackColor = Color.LightGreen;
                        dayButtons[currentRow, currentCol].ForeColor = Color.Black;
                    }

                    currentCol++;
                    if (currentCol > 6)
                    {
                        currentCol = 0;
                        currentRow++;
                    }
                }
            }
        }

        private void DayButton_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null && !string.IsNullOrEmpty(btn.Text))
            {
                int day = int.Parse(btn.Text);
                int persianYear = persianCalendar.GetYear(currentDate);
                int persianMonth = persianCalendar.GetMonth(currentDate);

                selectedDate = persianCalendar.ToDateTime(persianYear, persianMonth, day, 0, 0, 0, 0);
                UpdateCalendar();
                OnDateSelected(selectedDate);
            }
        }

        public event EventHandler<DateSelectedEventArgs> DateSelected;
        protected virtual void OnDateSelected(DateTime date)
        {
            DateSelected?.Invoke(this, new DateSelectedEventArgs(date));
        }
    }

    public class DateSelectedEventArgs : EventArgs
    {
        public DateTime SelectedDate { get; private set; }

        public DateSelectedEventArgs(DateTime date)
        {
            SelectedDate = date;
        }
    }
}